﻿起動方法:
1) このフォルダを任意の場所に置く
2) VerticalScenarioEditer.exe を実行

アンインストール:
このフォルダを削除
